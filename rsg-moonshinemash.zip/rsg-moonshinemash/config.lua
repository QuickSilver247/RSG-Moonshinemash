Config = {}

-- settings
Config.Prop = 'p_barrelhalf04x' -- prop used for the moonshine
Config.JobName = 'police' -- job that can distroy moonshines
Config.BrewTime = 15000 -- brewtime in milliseconds
Config.Animation = {}
Config.ProgressBar = true