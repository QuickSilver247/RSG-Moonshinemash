
# Rexshack RedM framework
- https://discord.gg/s5uSk56B65

# JD McCandles#9139 Dustbowl RP

# Dependancies
- rsg-core
- rsg-menu

# Installation
- ensure that the dependancies are added and started
- add rsg-moonshiner to your resources folder
- add items to your "\rsg-core\shared\items.lua"
- add images to your "\rsg-inventory\html\images"
- adjust the config.lua as required

# Starting the resource
- add the following to your server.cfg file : ensure rsg-moonshinemash