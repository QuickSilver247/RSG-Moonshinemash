	['bootlegger'] = { --valentine
        label = 'moonshiner',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = {
                name = 'Worker',
                payment = 25
            },
            ['1'] = {
                name = 'Mash Prep',
                payment = 50
            },
            ['2'] = {
                name = 'Master distiller',
                isboss = true,
                payment = 75
            },
        },
	},